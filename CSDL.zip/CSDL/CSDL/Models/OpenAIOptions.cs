﻿namespace CSDL.Models
{
    public class OpenAIOptions
    {
        public string ApiKey { get; set; }
        public string BaseUrl { get; set; }
        public string Referer { get; set; }
        public string Title { get; set; }
    }
}
